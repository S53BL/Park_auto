# AGENT NAVODILO — Integracija signal_led.cpp / signal_led.h
**Projekt:** Avtomatizacija Pokritega Parkirišča  
**Datum:** 2026-05  
**Datoteki:** signal_led.h, signal_led.cpp  
**Prioriteta:** Visoka — zamenja vse placeholder signalne animacije v led_manager.cpp

---

## KAJ JE TO

`signal_led.cpp/h` je nov Layer-3 modul ki prevzame upravljanje
144-LED signalne verige (IO40). Implementira 4 prioritetne scenarije:
- P1 SIG_RAMP      — animacija pomika rampe (comet, eksplozija)
- P2 SIG_PARKING   — parking assist (premikajoča skupina, cone)
- P3 SIG_PHOTOCELL — fotocelični alarm (dve coni, nočni mode)
- P4 SIG_CLOCK     — analogna ura (6 segmentov, minute marker)

Pred tem so bili ti scenariji implementirani kot preprosti placeholderji
direktno v led_manager.cpp. Ta integracija jih izloči v ločen modul.

---

## KORAK 1 — Kopiraj datoteki v projekt

Kopiraj `signal_led.h` in `signal_led.cpp` v `src/` direktorij projekta.
(Enako mesto kot led_manager.cpp, light_logic.cpp itd.)

---

## KORAK 2 — Spremembe v `led_manager.cpp`

### 2.1 Dodaj include na vrhu (za obstoječe include-e)

```cpp
#include "signal_led.h"
```

### 2.2 V `led_mgr_init()` — dodaj inicializacijo signal_led

Poišči kodo takoj po vrstici `FastLED.show();` (prva show po inicializaciji bufferjev),
pred `s_cmd_queue = xQueueCreate(...)`.

Dodaj:

```cpp
    // Inicializacija signal_led modula — pošlji kazalec na s_leds_signal buffer.
    // signal_led.cpp bo pisal direktno v ta buffer, led_manager bo klical show().
    // Mora biti po FastLED.addLeds<>() ker FastLED buffer takrat že obstaja.
    if (!signal_led_init(s_leds_signal, LED_SIGNAL_COUNT)) {
        LEDE("signal_led_init napaka — signalne animacije ne bodo delovale!");
        // Ne vrnemo false — projekt deluje brez signal LED animacij
    }
```

### 2.3 V `ledTask()` — korak 3 (animacijski frame signalne LED)

Poišči komentar `// 3. Animacijski frame — signalna LED` v ledTask while zanki.

**ZAMENJAJ** celoten switch blok (od `switch (s_sig_state)` do zapirajočega `}`)
z enim klicem:

```cpp
        // -------------------------------------------------------
        // 3. Animacijski frame — signalna LED
        // -------------------------------------------------------
        // signal_led_tick() je centralni dispečer za vse signalne scenarije.
        // Piše direktno v s_leds_signal[] buffer.
        // FastLED.show() (korak 4) bo te vrednosti poslal na IO40.
        signal_led_tick();
```

### 2.4 Izbriši (ali zakomentiraj) stare funkcije v led_manager.cpp

Ker signal_led.cpp prevzame logiko, te funkcije niso več potrebne.
**Zakomentiraj** (ne briši — olajša diff pri debug) naslednje statične funkcije:

- `anim_parking_assist_tick(const Config& cfg)` — zamenjana
- `anim_clock_tick()` — zamenjana
- `anim_celica_tick()` — zamenjana

**Komentar za blok:**
```cpp
// ============================================================
// OPUŠČENO — 2026-05: preneseno v signal_led.cpp
// Te funkcije so bile placeholder implementacije signalnih animacij.
// signal_led.cpp implementira polne verzije vseh scenarijev.
// ============================================================
```

### 2.5 Iz LedCmd enuma ODSTRANI (ali označi kot deprecated):

```cpp
    PARKING_ASSIST,     // → zamenjano: pokliči signal_led_parking_update() direktno
    PARKING_ASSIST_OFF, // → zamenjano: pokliči signal_led_parking_stop() direktno
    SHOW_CLOCK,         // → zamenjano: pokliči signal_led_clock_show() direktno
    CELICA_TIMER_ON,    // → zamenjano: pokliči signal_led_photocell_update() direktno
    CELICA_TIMER_OFF,   // → zamenjano: pokliči signal_led_photocell_stop() direktno
    SIGNAL_OFF,         // → zamenjano: pokliči signal_led_off() direktno
```

**POZOR:** Preden odstraniš te case iz switch bloka v ledTask, preveri kateri callerji
jih kličejo (korak 3 spodaj). Šele ko so callerji posodobljeni, odstraniš case-e.
Varnejše: pusti case-e v switch, samo dodaj `signal_led_*` klice v API wrapper funkcije.

### 2.6 Posodobi wrapper funkcije v led_manager.cpp

Poišči implementacije javnih API funkcij in jih preusmeri na signal_led:

```cpp
void led_mgr_parking_assist(ParkPlace place, uint32_t dist_mm) {
    // Parking assist je sedaj direktno v signal_led modulu.
    // ParkPlace se za zdaj ignorira (samo mesto A je podprto — arhitekturna odločitev).
    // TODO: ko bo mesto B implementirano, dodaj logiko tukaj.
    if (place == ParkPlace::A) {
        signal_led_parking_update(dist_mm);
    }
    // Stara implementacija prek queue je opuščena:
    // send_cmd(LedCmd::PARKING_ASSIST, dist_mm);
}

void led_mgr_parking_assist_off() {
    signal_led_parking_stop();
    // send_cmd(LedCmd::PARKING_ASSIST_OFF, 0);  // opuščeno
}

void led_mgr_show_clock(uint32_t duration_ms) {
    // duration_ms parameter se ignorira — signal_led bere iz config SIG_CLOCK_DURATION_MS
    // (nastavljivo prek web UI). Parametr ohranimo za API kompatibilnost.
    (void)duration_ms;
    signal_led_clock_show();
    // send_cmd(LedCmd::SHOW_CLOCK, duration_ms);  // opuščeno
}

void led_mgr_celica_timer(bool active) {
    // POZOR: stara API ni imela celica1/celica2 ločeno in ni vedela za nočni mode.
    // Ob klicu iz obstoječe kode: predpostavi celica1=active, celica2=false, noč=false.
    // Klicatelji (light_logic.cpp, sensor_mgr.cpp) morajo biti posodobljeni —
    // glej Korak 3 tega navodila.
    if (active) {
        signal_led_photocell_update(true, false, false);
    } else {
        signal_led_photocell_stop();
    }
}

void led_mgr_signal_off() {
    signal_led_off();
    // send_cmd(LedCmd::SIGNAL_OFF, 0);  // opuščeno
}
```

### 2.7 Odstrani AnimState vrednosti ki niso več potrebne

V `AnimState` enumu:
- `PARKING_ASSIST` — ni več potrebno (signal_led ima lasten state)
- `CLOCK_SHOW`     — ni več potrebno
- `CELICA_BLINK`   — ni več potrebno

Pusti samo tiste ki so še v uporabi za signalno LED (če kateri ostane).

---

## KORAK 3 — Spremembe v `light_logic.cpp`

### 3.1 Dodaj include

```cpp
#include "signal_led.h"
```

### 3.2 Dodaj klic clock animacije ob gibanju PODNEVI

V funkciji `on_radar_motion()`, v sekciji `// VEDNO — ne glede na dan/noč`,
takoj po posodobitvi anti-forget timerjev, dodaj:

```cpp
    // Prikaz ure PODNEVI ob zaznavi gibanja (P4 — najnižja prioriteta).
    // signal_led notranje preveri ali je clock v konfliktu z višjo prioriteto
    // in v tem primeru zakasni prikaz.
    // is_night flag berebmo iz s_is_night (lokalna spremenljivka light_logic).
    if (!s_is_night) {
        signal_led_clock_show();
    }
```

### 3.3 Dodaj klic rampa animacije

V funkciji `on_ramp_up()`, po enqueue klicu, dodaj klic rampa animacije:

```cpp
static void on_ramp_up(const Event& e) {
    if (!e.payload) return;
    // Rampa se dviga — sproži animacijo na signalnem traku (P1, preglasi vse).
    // Animacija teče dokler ne pride on_ramp_stop() ali rampaluc = HIGH.
    signal_led_ramp_start(RampDir::UP);
    if (!s_is_night) { LLD("RAMP_UP: animacija (podnevi)"); return; }
    LLD("RAMP_UP → enqueue TRIGGER_ON_AUTO (počasen fill)");
    ssr_cmd_enqueue(SsrCmdType::TRIGGER_ON_AUTO, LIGHT_FADE_SLOW_MS);
}
```

V funkciji `on_ramp_moving()`:

```cpp
static void on_ramp_moving(const Event& e) {
    if (!e.payload) return;
    // rampaluc aktiven → comet animacija dol (rampa se spušča)
    signal_led_ramp_start(RampDir::DOWN);
    if (!s_is_night) { LLD("RAMP_MOVING: animacija (podnevi)"); return; }
    LLD("RAMP_MOVING → enqueue TRIGGER_ON_AUTO (počasen fill)");
    ssr_cmd_enqueue(SsrCmdType::TRIGGER_ON_AUTO, LIGHT_FADE_SLOW_MS);
}
```

### 3.4 Dodaj EventBus subscriber za RAMP_DOWN in RAMP_STOP

V `light_logic_init()`, po obstoječih subscribe klicih, dodaj:

```cpp
    // RAMP_STOP: rampaluc je šel HIGH (rampa ustavljena) — zaključi animacijo
    // EventType::RAMP_STOP mora biti definiran v event_bus.h (glej Korak 5)
    EventBus::subscribe(EventType::RAMP_STOP, on_ramp_stop);
```

Dodaj handler funkcijo (pred light_logic_init()):

```cpp
// RAMP_STOP — rampaluc je šel HIGH (rampa se je ustavila)
// Sproži dramatičen konec rampa animacije na signalnem traku.
static void on_ramp_stop(const Event& e) {
    SIGD("RAMP_STOP → zaključujem rampa animacijo");
    signal_led_ramp_stop();
}
```

**OPOMBA:** Preveri ali je RAMP_STOP event že definiran v event_bus.h.
Alternativno: RAMP_UP z payload=0 pomeni "rampa dol/stop" — preveri obstoječo logiko v hal_gpio.cpp.

---

## KORAK 4 — Spremembe v `sensor_mgr.cpp`

### 4.1 Dodaj include

```cpp
#include "signal_led.h"
```

### 4.2 Posodobi parking assist feed

Poišči mesto kjer se kliče `led_mgr_parking_assist()` (ali TODO komentar za to).
Zamenjaj z direktnim klicem ali preveri da gre prek led_mgr_parking_assist():

```cpp
// V sensor_mgr, kjer se procesirajo TOF H meritve med Fazo 2:
// (poišči: case FASE_2 ali TOF_PHASE_DETECT ali podobno)

// Ko je faza 2 aktivna in je H_mm < pa_thresh_green_mm:
if (tof_phase == TOF_PHASE_DETECT && active_place == PARK_A) {
    led_mgr_parking_assist(ParkPlace::A, H_mm);  // ta klic zdaj gre v signal_led
}

// Ko faza 2 konča (vozilo stabilno):
if (faza_zakljucena) {
    led_mgr_parking_assist_off();  // ta klic zdaj gre v signal_led
}
```

### 4.3 Posodobi fotocelice feed

Poišči obstoječ klic `led_mgr_celica_timer()` (ali TODO komentar).
Zamenjaj z novim API klicem ki pozna obe celici in nočni mode:

```cpp
// Poišči: EventBus handler za CELL_BROKEN ali direktni klic v sensor_mgr

// Ko fotocelica prekinjena (light_logic.cpp ima s_is_night):
// Ker sensor_mgr nima direktnega dostopa do s_is_night iz light_logic,
// uporabimo hal_light_get_is_night() ki je že dostopen:
#include "hal_light.h"

// Ob CELL_BROKEN eventu ali direktnem zaznavanju:
bool celica1 = hal_gpio_read_pin(PIN_CELICA1) == LOW;  // ali EVENT payload
bool celica2 = hal_gpio_read_pin(PIN_CELICA2) == LOW;
bool is_night = hal_light_get_is_night();

signal_led_photocell_update(celica1, celica2, is_night);

// Ko obe celici OK:
signal_led_photocell_stop();
```

**POZOR:** Preveri točno kako so CELL_BROKEN eventi implementirani v hal_gpio.cpp
in kako sensor_mgr/light_logic jih procesira. Mogoče je klic že v light_logic.cpp —
v tem primeru dodaj `#include "signal_led.h"` in klic tam, ne v sensor_mgr.

---

## KORAK 5 — Preveri event_bus.h

Odpri `event_bus.h` in preveri ali obstajajo naslednji EventType-i:

```
RAMP_UP      — rampa se dviga (rampaluc ali rampagor signal)
RAMP_MOVING  — rampa se premika (raluc signal)
RAMP_STOP    — rampa se je ustavila (rampaluc = HIGH)
CELL_BROKEN  — fotocelica prekinjena
```

Če `RAMP_STOP` ne obstaja: dodaj ga. Preveri kako `hal_gpio.cpp` obravnava
MCP23017 GPA1 (rampaluc) — HIGH pomeni "rampa ustavljena".
Mogoče je to že kodirano kot RAMP_MOVING z payload=0 ali RAMP_UP z payload=0.
Prilagodi `on_ramp_stop()` glede na dejansko implementacijo.

---

## KORAK 6 — Preveritve pred buildanjem

### 6.1 Zagotovi da v config.h obstajajo vse konstante:

```cpp
// Sekcija 14 — SIGNALNA LED PARAMETRI (že obstajajo v config.h v2.0.0-dev):
#define SIG_PARK_THRESH_GREEN   1500
#define SIG_PARK_THRESH_ORANGE  1000
#define SIG_PARK_THRESH_RED     500
#define SIG_PARK_STABLE_MS      4000
#define SIG_CELL_TIMER_MS       (5 * 60 * 1000)
#define SIG_CLOCK_DURATION_MS   10000
```

### 6.2 Zagotovi da v config_mgr.h Config struct vsebuje:

```cpp
uint32_t pa_thresh_green_mm;    // privzeto: SIG_PARK_THRESH_GREEN (1500)
uint32_t pa_thresh_orange_mm;   // privzeto: SIG_PARK_THRESH_ORANGE (1000)
uint32_t pa_thresh_red_mm;      // privzeto: SIG_PARK_THRESH_RED (500)
```

Če Config ne vsebuje teh polj: dodaj jih v Config struct v config_mgr.h
in nastavi privzete vrednosti v config_defaults() funkciji.

### 6.3 Preveri ali led_manager.h eksportira safe_show()

`signal_led_tick()` NE kliče show() sam — to počne led_manager.
Preveriti da vrstni red v ledTask ni bil spremenjen:
```
led step 3: signal_led_tick()   // piše v buffer
led step 4: safe_show()        // pošlje buffer na fizične LED
```
Ta vrstni red je kritičen — če je obraten, signal_led izpis zamuja 1 frame.

---

## KORAK 7 — Diagnostika: razširi `/api/status` in web UI

### 7.1 V web_ui.cpp — dodaj signal_led stats v /api/status odgovor:

Poišči `GET /api/status` handler. Dodaj v JSON odgovor:

```cpp
// V sekciji kjer se gradi status JSON:
#include "signal_led.h"

SignalLedStats sig_stats = signal_led_get_stats();
// Dodaj v JSON (odvisno od JSON knjižnice ki jo projekt uporablja):
// "signal_led": {
//   "mode": signal_led_mode_name(sig_stats.current_mode),
//   "mode_changes": sig_stats.mode_changes,
//   "ramp_activations": sig_stats.ramp_activations,
//   "preemptions": sig_stats.preemptions
// }
```

### 7.2 V status.js — dodaj Signal LED sekcijo na Status strani:

Poišči kjer se renderirajo senzorji na status strani.
Dodaj majhno kartico:

```javascript
// V renderStatus() funkciji:
if (d.signal_led) {
    html += `<div class="card">
        <b>Signalna LED</b><br>
        Način: <b>${d.signal_led.mode}</b><br>
        Preklopov: ${d.signal_led.mode_changes} | 
        Prekinitev: ${d.signal_led.preemptions}
    </div>`;
}
```

---

## KORAK 8 — Build in test

### Build test (samo prevajanje — nalaganje je ročno):
```
pio run
```

Pričakovana opozorila ki so OK:
- "unused variable 's_last_logged_min'" v signal_led.cpp → normalno (static local)
- "comparison of unsigned" → normalno za millis() primerjave

Napake ki jih je treba odpraviti:
- "'SIG_CLOCK_DURATION_MS' undeclared" → dodaj v config.h sekcija 14
- "'signal_led_init' undefined" → ni dodan include v led_manager.cpp
- "'pa_thresh_green_mm' has no member" → dodaj polje v Config struct

### Verifikacija po flashu — pričakovani log ob zagonu:
```
[SIGLED:INFO] === signal_led_init ===
[SIGLED:INFO] signal_led_init OK — buf=0x3fXXXXXX, count=144
[LED:INFO]    led_mgr_init OK — main:90 LED (×10 fizično) signal:144 LED
```

### Test P4 (ura) — najlažji za preveritev brez HW:
1. Podnevi (ali začasno: `s_is_night = false`)
2. Premakni roko pred radar senzorjem
3. Pričakovano v logu: `[SIGLED:DEBUG] CLOCK: cona=X ura=HH:MM seg_lit=N marker@NNN`
4. Signalni trak prikaže uro 10s, nato ugasne

### Test P3 (fotocelice):
1. Kliči `signal_led_photocell_update(true, false, false)` iz debug konzole ali web UI
2. Pričakovano: BOT cona (LED 0–47) utripa rdeče/oranžno, 1 Hz
3. Po 5 minutah: samodejni izklop s logom `[SIGLED:INFO] CELL: 5-minutni timer iztekel`

### Test P2 (parking assist):
1. Kliči `signal_led_parking_update(1200)` (med 1500–1000mm → zelena cona)
2. Pričakovano: premikajoča skupina 10 zelenih LED
3. Kliči z vrednostjo 200 → rdeča + utripanje
4. Kliči `signal_led_parking_stop()` → zelena wave + fadeout

### Test P1 (rampa) — zahteva HW ali mock:
1. Mock: pokliči `signal_led_ramp_start(RampDir::UP)` direktno iz test kode
2. Pričakovano: 2× oranžni blisk, nato comet navzgor
3. Po 3–4 prehodih: `signal_led_ramp_stop()` → upočasnitev → eksplozija → 5s fadeout

---

## POVZETEK DATOTEK KI JIH AGENT UREJA

| Datoteka | Vrsta spremembe | Prioriteta |
|---|---|---|
| `src/signal_led.h` | NOVA — samo kopira | Obvezno |
| `src/signal_led.cpp` | NOVA — samo kopira | Obvezno |
| `src/led_manager.cpp` | Sprememba — init, tick, wrapperji | Obvezno |
| `src/light_logic.cpp` | Sprememba — rampa + ura klici | Obvezno |
| `src/sensor_mgr.cpp` | Sprememba — parking + celice feed | Obvezno |
| `src/config.h` | Preveritev — sekcija 14 konstante | Preveri |
| `src/config_mgr.h` | Preveritev — Config struct polja | Preveri |
| `src/event_bus.h` | Preveritev — RAMP_STOP event | Preveri |
| `src/web_ui.cpp` | Razširitev — signal_led stats v /api/status | Opcijsko |
| `src/assets/status.js` | Razširitev — Signal LED kartica | Opcijsko |

## OPOMBA ZA AGENTA

Prevajanje kode in nalaganje na GIT je ročno delo lastnika projekta.
Agent naredi vse spremembe in preveri da se projekt prevede (`pio run`).
Ne nalagaj na GIT, ne flashaj.

Ob nejasnostih glede obstoječe implementacije (npr. kako je CELL_BROKEN
implementiran v hal_gpio.cpp): preveri obstoječo kodo in se prilagodi —
ne uvajaj novih EventType-ov kjer niso potrebni.
