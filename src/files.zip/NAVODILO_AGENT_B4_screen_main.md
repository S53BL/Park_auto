# B4 — Spremembe v screen_main.cpp

**Datum:** 2026-05-14
**Obseg:** 5 sprememb, ~120 vrstic skupaj
**Predpogoj:** vehicle_recog.h je že v src/

---

## 1. Dodaj include in EventBus subscribe

**Na vrhu datoteke, za obstoječe #include-e:**

```cpp
#include "vehicle_recog.h"   // vr_place_state_t, vehicle_recog_get_*
```

---

## 2. ParkingDisplayData — razširi struct (screen_main.h)

Najdi obstoječ struct `ParkingDisplayData` v `screen_main.h`.
**Dodaj polja** (ne briši obstoječih):

```cpp
struct ParkingDisplayData {
    bool     occupied;
    char     vehicle_name[32];
    uint32_t parking_count;
    float    dtw_distance;
    uint8_t  tof_phase;     // 0=IDLE, 1=DETECT, 2=SCAN, 3=DTW_WAIT (obstoječe)
    bool     tof_active;    // (obstoječe)
    uint16_t horiz_mm;      // (obstoječe)

    // ---- NOVO (B4) ----
    // vr_place_state_t vrednosti: 0=EMPTY_CAL, 1=EMPTY_UNCAL, 2=OCC_UNKNOWN, 3=OCC_KNOWN
    uint8_t  vr_state;      // vehicle_recog state (0–3)
    bool     baseline_valid; // true = baseline kalibriran
    float    last_dtw;      // zadnja DTW razdalja (NAN = ni)
};
```

---

## 3. Zamenjaj pkg_event_cb — doda 2s in 10s long press

**Najdi obstoječ `pkg_event_cb`:**

```cpp
static void pkg_event_cb(lv_event_t* e) {
    if (lv_event_get_code(e) != LV_EVENT_LONG_PRESSED) return;
    PkgWidget* w = (PkgWidget*)lv_event_get_user_data(e);
    if (!w) return;
    EventBus::publish(
        w->idx == 0 ? EventType::BUTTON_EDIT_VEHICLE_A
                    : EventType::BUTTON_EDIT_VEHICLE_B, 0);
}
```

**Zamenjaj Z:**

```cpp
// Timing za long press — per mesto, statično
static uint32_t s_pkg_press_ms[2]   = {0, 0};
static bool     s_pkg_edit_fired[2] = {false, false};   // 2s fired
static bool     s_pkg_cal_fired[2]  = {false, false};   // 10s fired

static void pkg_event_cb(lv_event_t* e) {
    lv_event_code_t code = lv_event_get_code(e);
    PkgWidget* w = (PkgWidget*)lv_event_get_user_data(e);
    if (!w) return;
    uint8_t i = w->idx;  // 0=A, 1=B
    char pid = (i == 0) ? 'A' : 'B';

    if (code == LV_EVENT_PRESSED) {
        s_pkg_press_ms[i]   = millis();
        s_pkg_edit_fired[i] = false;
        s_pkg_cal_fired[i]  = false;
    }
    else if (code == LV_EVENT_PRESSING) {
        uint32_t held = millis() - s_pkg_press_ms[i];

        // 2s: uredi ime — samo v OCCUPIED_* stanjih (dodatek pogl. 11)
        if (held >= 2000 && !s_pkg_edit_fired[i]) {
            vr_place_state_t st = vehicle_recog_get_state(pid);
            if (st == VR_STATE_OCCUPIED_KNOWN || st == VR_STATE_OCCUPIED_UNKNOWN) {
                s_pkg_edit_fired[i] = true;
                SMNI("PKG[%c] 2s hold → BUTTON_EDIT_VEHICLE", pid);
                EventBus::publish(
                    i == 0 ? EventType::BUTTON_EDIT_VEHICLE_A
                           : EventType::BUTTON_EDIT_VEHICLE_B, 0);
                // Odpri rename dialog takoj
                pkg_open_rename_dialog(i);
            }
        }

        // 10s: kalibriraj prazno — samo v EMPTY_* stanjih (dodatek pogl. 11)
        if (held >= VR_CALIB_HOLD_MS && !s_pkg_cal_fired[i]) {
            vr_place_state_t st = vehicle_recog_get_state(pid);
            if (st == VR_STATE_EMPTY_CALIBRATED || st == VR_STATE_EMPTY_UNCALIBRATED) {
                s_pkg_cal_fired[i] = true;
                SMNI("PKG[%c] 10s hold → calibrate dialog", pid);
                pkg_open_calibrate_dialog(i);
            }
        }
    }
    else if (code == LV_EVENT_RELEASED || code == LV_EVENT_PRESS_LOST) {
        s_pkg_press_ms[i]   = 0;
        s_pkg_edit_fired[i] = false;
        s_pkg_cal_fired[i]  = false;
    }
}
```

---

## 4. Dodaj pkg_open_rename_dialog() in pkg_open_calibrate_dialog()

Vstavi **pred** `pkg_event_cb`:

```cpp
// ── RENAME DIALOG: LVGL keyboard + textarea (dodatek_vehicle_recog.md pogl. 11) ──
// Tekstovno polje ZGORAJ, tipkovnica POD njim, maksimalna velikost.
// Blokirano med dinamicnimi fazami — preverjanje je ze v pkg_event_cb (vr_state).
// ──────────────────────────────────────────────────────────────────────────────────
static uint8_t s_rename_pkg_idx = 0;  // kateri parking widget preimenujemo

static void pkg_rename_ok_cb(lv_event_t* e) {
    lv_event_code_t code = lv_event_get_code(e);
    if (code != LV_EVENT_CLICKED && code != LV_EVENT_VALUE_CHANGED) return;

    // Vrednost se ujema samo za LV_EVENT_CLICKED (OK gumb) ali
    // LV_EVENT_VALUE_CHANGED (Enter na tipkovnici)
    if (code == LV_EVENT_VALUE_CHANGED) {
        // Tipkovnica je spremenila vrednost — pritisnjena je bila tipka.
        // Za "OK" potrebujemo klik na gumb, ne VALUE_CHANGED.
        return;
    }

    // Pridobi textarea iz user_data
    lv_obj_t* ta = (lv_obj_t*)lv_event_get_user_data(e);
    if (!ta) return;
    const char* new_name = lv_textarea_get_text(ta);
    if (!new_name || strlen(new_name) == 0) return;

    char pid = (s_rename_pkg_idx == 0) ? 'A' : 'B';
    const char* model_id = vehicle_recog_get_model_id(pid);
    if (model_id && strlen(model_id) > 0) {
        bool ok = vehicle_recog_rename_model(pid, model_id, new_name);
        SMNI("PKG[%c] rename '%s' → ok=%d", pid, new_name, (int)ok);
    }

    // Zapri dialog (parent je modal screen)
    lv_obj_t* modal = lv_obj_get_parent(lv_obj_get_parent(e ? lv_event_get_target(e) : nullptr));
    // Ker je struktura: screen → container → gumb, gremo 2 nivoja gor
    // Zanesljiveje: pobrisi zadnji child screen-a (= modal)
    lv_obj_t* scr = lv_scr_act();
    uint32_t child_cnt = lv_obj_get_child_count(scr);
    if (child_cnt > 0) {
        lv_obj_del(lv_obj_get_child(scr, child_cnt - 1));
    }
}

static void pkg_open_rename_dialog(uint8_t pkg_idx) {
    s_rename_pkg_idx = pkg_idx;
    char pid = (pkg_idx == 0) ? 'A' : 'B';
    const char* cur_name = vehicle_recog_get_vehicle_name(pid);

    // Modal container — cela zaslon
    lv_obj_t* modal = lv_obj_create(lv_scr_act());
    lv_obj_set_size(modal, LV_PCT(100), LV_PCT(100));
    lv_obj_set_style_bg_color(modal, lv_color_hex(0x0A0F1A), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(modal, 230, LV_PART_MAIN);
    lv_obj_set_style_border_width(modal, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(modal, 0, LV_PART_MAIN);
    lv_obj_clear_flag(modal, LV_OBJ_FLAG_SCROLLABLE);

    // Textarea zgoraj (dodatek pogl. 11: tekstovno polje ZGORAJ)
    lv_obj_t* ta = lv_textarea_create(modal);
    lv_obj_set_size(ta, 300, 44);
    lv_obj_align(ta, LV_ALIGN_TOP_MID, 0, 10);
    lv_textarea_set_max_length(ta, 31);
    lv_textarea_set_one_line(ta, true);
    lv_textarea_set_text(ta, cur_name ? cur_name : "");
    lv_obj_set_style_text_font(ta, &font_montserrat_18_sl, LV_PART_MAIN);
    lv_obj_set_style_text_color(ta, lv_color_hex(0xF1F5F9), LV_PART_MAIN);
    lv_obj_set_style_bg_color(ta, lv_color_hex(0x1E2A2F), LV_PART_MAIN);
    lv_obj_set_style_border_color(ta, lv_color_hex(0x60A5FA), LV_PART_MAIN);
    lv_obj_set_style_border_width(ta, 2, LV_PART_MAIN);
    lv_obj_set_style_radius(ta, 6, LV_PART_MAIN);

    // Tipkovnica pod tekstovnim poljem (maksimalna velikost)
    lv_obj_t* kb = lv_keyboard_create(modal);
    lv_keyboard_set_mode(kb, LV_KEYBOARD_MODE_TEXT_UPPER);
    lv_keyboard_set_textarea(kb, ta);
    // Tipkovnica zavzame spodnje 2/3 zaslona — LVGL jo avtomatsko pozicionira
    // na dno ce je parent fullscreen. Eksplicitno pozicioniranje:
    lv_obj_set_size(kb, LV_PCT(100), LV_PCT(60));
    lv_obj_align(kb, LV_ALIGN_BOTTOM_MID, 0, 0);
    lv_obj_set_style_bg_color(kb, lv_color_hex(0x1A2035), LV_PART_MAIN);

    // OK gumb (zraven textarea)
    lv_obj_t* ok_btn = lv_btn_create(modal);
    lv_obj_set_size(ok_btn, 60, 36);
    lv_obj_align_to(ok_btn, ta, LV_ALIGN_OUT_RIGHT_MID, 6, 0);
    lv_obj_set_style_bg_color(ok_btn, lv_color_hex(0x1D4E3A), LV_PART_MAIN);
    lv_obj_set_style_radius(ok_btn, 6, LV_PART_MAIN);
    lv_obj_add_event_cb(ok_btn, pkg_rename_ok_cb, LV_EVENT_CLICKED, ta);
    lv_obj_t* ok_lbl = lv_label_create(ok_btn);
    lv_label_set_text(ok_lbl, "OK");
    lv_obj_center(ok_lbl);

    // Cancel gumb
    lv_obj_t* cancel_btn = lv_btn_create(modal);
    lv_obj_set_size(cancel_btn, 60, 36);
    lv_obj_align_to(cancel_btn, ok_btn, LV_ALIGN_OUT_RIGHT_MID, 6, 0);
    lv_obj_set_style_bg_color(cancel_btn, lv_color_hex(0x2A1F1F), LV_PART_MAIN);
    lv_obj_set_style_radius(cancel_btn, 6, LV_PART_MAIN);
    lv_obj_add_event_cb(cancel_btn, [](lv_event_t* ev) {
        if (lv_event_get_code(ev) != LV_EVENT_CLICKED) return;
        lv_obj_t* scr = lv_scr_act();
        uint32_t n = lv_obj_get_child_count(scr);
        if (n > 0) lv_obj_del(lv_obj_get_child(scr, n - 1));
    }, LV_EVENT_CLICKED, nullptr);
    lv_obj_t* cancel_lbl = lv_label_create(cancel_btn);
    lv_label_set_text(cancel_lbl, "×");
    lv_obj_center(cancel_lbl);

    // Fokus na textarea
    lv_obj_scroll_to_view(ta, LV_ANIM_OFF);
}

// ── CALIBRATE DIALOG: DA/NE potrditev ──────────────────────────────────────
static uint8_t s_cal_pkg_idx = 0;

static void pkg_calibrate_confirm_cb(lv_event_t* e) {
    if (lv_event_get_code(e) != LV_EVENT_CLICKED) return;
    bool do_cal = (bool)(uintptr_t)lv_event_get_user_data(e);

    if (do_cal) {
        char pid = (s_cal_pkg_idx == 0) ? 'A' : 'B';
        bool ok = vehicle_recog_calibrate_empty(pid);
        SMNI("PKG[%c] calibrate_empty → ok=%d", pid, (int)ok);
        if (!ok) {
            // Toast: kratko opozorilo (2s)
            // Poenostavitev: samo log, ker toast ni implementiran
            SMNI("PKG[%c] calibrate NAPAKA (sensor ali state)", pid);
        }
    }

    // Zapri dialog
    lv_obj_t* scr = lv_scr_act();
    uint32_t n = lv_obj_get_child_count(scr);
    if (n > 0) lv_obj_del(lv_obj_get_child(scr, n - 1));
}

static void pkg_open_calibrate_dialog(uint8_t pkg_idx) {
    s_cal_pkg_idx = pkg_idx;
    char pid = (pkg_idx == 0) ? 'A' : 'B';

    // Modal
    lv_obj_t* modal = lv_obj_create(lv_scr_act());
    lv_obj_set_size(modal, LV_PCT(100), LV_PCT(100));
    lv_obj_set_style_bg_color(modal, lv_color_hex(0x0A0F1A), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(modal, 230, LV_PART_MAIN);
    lv_obj_set_style_border_width(modal, 0, LV_PART_MAIN);
    lv_obj_set_style_pad_all(modal, 0, LV_PART_MAIN);
    lv_obj_clear_flag(modal, LV_OBJ_FLAG_SCROLLABLE);

    // Dialog kartica
    lv_obj_t* card = lv_obj_create(modal);
    lv_obj_set_size(card, 260, 120);
    lv_obj_align(card, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_bg_color(card, lv_color_hex(0x1E2A2F), LV_PART_MAIN);
    lv_obj_set_style_radius(card, 10, LV_PART_MAIN);
    lv_obj_set_style_border_color(card, lv_color_hex(0x334155), LV_PART_MAIN);
    lv_obj_set_style_border_width(card, 1, LV_PART_MAIN);
    lv_obj_clear_flag(card, LV_OBJ_FLAG_SCROLLABLE);

    // Naslov
    lv_obj_t* title = lv_label_create(card);
    char title_buf[48];
    snprintf(title_buf, sizeof(title_buf), "Kalibriraj prazno mesto %c?", pid);
    lv_label_set_text(title, title_buf);
    lv_obj_set_style_text_font(title, &font_montserrat_16_sl, LV_PART_MAIN);
    lv_obj_set_style_text_color(title, lv_color_hex(0xF1F5F9), LV_PART_MAIN);
    lv_obj_align(title, LV_ALIGN_TOP_LEFT, 10, 10);
    lv_label_set_long_mode(title, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(title, 240);

    // Podbesedilo
    lv_obj_t* hint = lv_label_create(card);
    lv_label_set_text(hint, "Mesto mora biti prazno.");
    lv_obj_set_style_text_font(hint, &font_montserrat_14_sl, LV_PART_MAIN);
    lv_obj_set_style_text_color(hint, lv_color_hex(0x94A3B8), LV_PART_MAIN);
    lv_obj_align(hint, LV_ALIGN_TOP_LEFT, 10, 36);

    // Gumb DA
    lv_obj_t* yes_btn = lv_btn_create(card);
    lv_obj_set_size(yes_btn, 100, 36);
    lv_obj_align(yes_btn, LV_ALIGN_BOTTOM_LEFT, 10, -10);
    lv_obj_set_style_bg_color(yes_btn, lv_color_hex(0x1D4E3A), LV_PART_MAIN);
    lv_obj_set_style_radius(yes_btn, 6, LV_PART_MAIN);
    lv_obj_add_event_cb(yes_btn, pkg_calibrate_confirm_cb,
                        LV_EVENT_CLICKED, (void*)(uintptr_t)1);
    lv_obj_t* yes_lbl = lv_label_create(yes_btn);
    lv_label_set_text(yes_lbl, "DA — Kalibriraj");
    lv_obj_set_style_text_font(yes_lbl, &font_montserrat_14_sl, LV_PART_MAIN);
    lv_obj_center(yes_lbl);

    // Gumb NE
    lv_obj_t* no_btn = lv_btn_create(card);
    lv_obj_set_size(no_btn, 80, 36);
    lv_obj_align(no_btn, LV_ALIGN_BOTTOM_RIGHT, -10, -10);
    lv_obj_set_style_bg_color(no_btn, lv_color_hex(0x2A1F1F), LV_PART_MAIN);
    lv_obj_set_style_radius(no_btn, 6, LV_PART_MAIN);
    lv_obj_add_event_cb(no_btn, pkg_calibrate_confirm_cb,
                        LV_EVENT_CLICKED, (void*)(uintptr_t)0);
    lv_obj_t* no_lbl = lv_label_create(no_btn);
    lv_label_set_text(no_lbl, "NE");
    lv_obj_set_style_text_font(no_lbl, &font_montserrat_14_sl, LV_PART_MAIN);
    lv_obj_center(no_lbl);
}
```

---

## 5. Posodobi pkg_apply() — uporabi vr_state za parking kartico

**Najdi obstoječ `pkg_apply()`** in **zamenjaj telo funkcije** (ohrani ime funkcije):

```cpp
static void pkg_apply(PkgWidget& w) {
    // ── State machine glede na vr_state (dodatek_vehicle_recog.md pogl. 11) ──
    // vr_state: 0=EMPTY_CALIBRATED, 1=EMPTY_UNCALIBRATED, 2=OCC_UNKNOWN, 3=OCC_KNOWN
    bool is_empty = (w.data.vr_state == VR_STATE_EMPTY_CALIBRATED
                  || w.data.vr_state == VR_STATE_EMPTY_UNCALIBRATED);

    if (w.data.vr_state == VR_STATE_OCCUPIED_KNOWN) {
        // Zelena ikona + ime + badge
        lv_obj_set_style_bg_color(w.card, C_PKG_OCC_BG, LV_PART_MAIN);
        lv_obj_set_style_border_color(w.card, C_PKG_OCC_BORDER, LV_PART_MAIN);
        lv_label_set_text(w.lbl_name,
            w.data.vehicle_name[0] ? w.data.vehicle_name : "Avto ?");
        lv_obj_set_style_text_color(w.lbl_name, C_PKG_OCC_NAME, LV_PART_MAIN);
        car_set_color(w.car, C_CAR_OCC);
        // Badge: "47× · DTW 8.3" (dodatek pogl. 11)
        char stats[40];
        if (!isnan(w.data.last_dtw)) {
            snprintf(stats, sizeof(stats), "%lu\xC3\x97  DTW %.1f",
                     (unsigned long)w.data.parking_count,
                     (double)w.data.last_dtw);
        } else {
            snprintf(stats, sizeof(stats), "novo");
        }
        lv_label_set_text(w.lbl_stats, stats);
    }
    else if (w.data.vr_state == VR_STATE_OCCUPIED_UNKNOWN) {
        // Siva ikona + "---" (dodatek pogl. 11)
        lv_obj_set_style_bg_color(w.card, C_PKG_OCC_BG, LV_PART_MAIN);
        lv_obj_set_style_border_color(w.card,
            lv_color_hex(0x475569), LV_PART_MAIN);  // priglušena oranžna
        lv_label_set_text(w.lbl_name, "---");
        lv_obj_set_style_text_color(w.lbl_name, C_CAR_EMPTY, LV_PART_MAIN);
        car_set_color(w.car, lv_color_hex(0x475569));  // siva
        lv_label_set_text(w.lbl_stats, "");
    }
    else {
        // EMPTY_CALIBRATED ali EMPTY_UNCALIBRATED — modra P ikona (dodatek pogl. 11)
        lv_obj_set_style_bg_color(w.card, C_PKG_EMPTY_BG, LV_PART_MAIN);
        lv_obj_set_style_border_color(w.card, C_PKG_EMPTY_BORDER, LV_PART_MAIN);
        lv_label_set_text(w.lbl_name, "Prazno");
        lv_obj_set_style_text_color(w.lbl_name, C_PKG_EMPTY_NAME, LV_PART_MAIN);
        car_set_color(w.car, C_CAR_EMPTY);
        // Badge "ni kalibr." ce nima baseline (dodatek pogl. 11)
        if (w.data.vr_state == VR_STATE_EMPTY_UNCALIBRATED) {
            lv_label_set_text(w.lbl_stats, "\xe2\x9a\xa0 ni kalibr.");  // ⚠
            lv_obj_set_style_text_color(w.lbl_stats,
                lv_color_hex(0xFBBF24), LV_PART_MAIN);
        } else {
            lv_label_set_text(w.lbl_stats, "");
        }
    }

    // ── TOF faza indikator (E3.2 — nespremenjen) ──
    uint8_t phase = w.data.tof_phase;
    lv_color_t phase_col;
    switch (phase) {
        case 1:  phase_col = C_PHASE_DETECT; break;
        case 2:  phase_col = C_PHASE_SCAN;   break;
        case 3:  phase_col = C_PHASE_DTW;    break;
        default: phase_col = C_PHASE_IDLE;   break;
    }
    if (w.data.tof_active && phase > 0) {
        lv_label_set_text(w.lbl_phase, PHASE_NAMES[phase]);
        lv_obj_set_style_text_color(w.lbl_phase, phase_col, LV_PART_MAIN);
        lv_obj_remove_flag(w.lbl_phase, LV_OBJ_FLAG_HIDDEN);
    } else {
        lv_obj_add_flag(w.lbl_phase, LV_OBJ_FLAG_HIDDEN);
    }

    // ── H razdalja (nespremenjena) ──
    if (w.data.horiz_mm > 0 && w.data.horiz_mm < 8000) {
        char buf[12];
        snprintf(buf, sizeof(buf), "%u cm", w.data.horiz_mm / 10);
        lv_label_set_text(w.lbl_horiz, buf);
        lv_obj_remove_flag(w.lbl_horiz, LV_OBJ_FLAG_HIDDEN);
    } else {
        lv_obj_add_flag(w.lbl_horiz, LV_OBJ_FLAG_HIDDEN);
    }
}
```

---

## 6. Posodobi hal_display.cpp — polni ParkingDisplayData iz vehicle_recog

**V hal_display.cpp najdi LVGL timer callback** (ui_refresh_cb ali ekvivalent)
ki kliče `screen_main_set_parking()`.

**Posodobi polnjenje ParkingDisplayData za vsako mesto (i=0=A, i=1=B):**

```cpp
// V ui_refresh_cb ali kjer se kliče screen_main_set_parking():
for (uint8_t i = 0; i < 2; i++) {
    char pid = (i == 0) ? 'A' : 'B';
    ParkingDisplayData pd = {};

    // ---- Obstoječi podatki ----
    TofDiagnostics tof = hal_tof_getDiagnostics();
    pd.tof_phase  = (uint8_t)tof.current_phase;
    pd.tof_active = ((uint8_t)tof.active_place == i
                     && tof.current_phase != TOF_PHASE_IDLE);
    pd.horiz_mm   = tof.last_mm[i == 0 ? TCA_CH_TOF_H_A : TCA_CH_TOF_H_B];

    // ---- NOVO: vehicle_recog state ----
    pd.vr_state       = (uint8_t)vehicle_recog_get_state(pid);
    pd.baseline_valid = vehicle_recog_get_baseline(pid).valid;
    pd.last_dtw       = vehicle_recog_get_last_dtw(pid);
    pd.occupied       = (pd.vr_state == VR_STATE_OCCUPIED_KNOWN
                      || pd.vr_state == VR_STATE_OCCUPIED_UNKNOWN);

    const char* vname = vehicle_recog_get_vehicle_name(pid);
    if (vname && *vname) {
        strncpy(pd.vehicle_name, vname, sizeof(pd.vehicle_name) - 1);
    } else {
        pd.vehicle_name[0] = '\0';
    }
    pd.parking_count = 0;  // opcijsko: vehicle_recog_get_model_summary za reps
    // Za parking_count: poišci model po current_model_id in vzemi reps
    // (poenostavitev: preskoči če ni kriticno za MVP)
    const char* mid = vehicle_recog_get_model_id(pid);
    if (mid && *mid) {
        uint16_t cnt = vehicle_recog_get_model_count(pid);
        for (uint16_t j = 0; j < cnt; j++) {
            vr_model_summary_t s;
            if (vehicle_recog_get_model_summary(pid, j, &s)
                && strcmp(s.id, mid) == 0) {
                pd.parking_count = (uint32_t)s.repetitions;
                break;
            }
        }
    }

    screen_main_set_parking(i, pd);
}
```

**Dodaj include v hal_display.cpp:**
```cpp
#include "vehicle_recog.h"
```

---

## 7. EventBus subscriber za screen posodobitev ob VEHICLE_RECOGNIZED

V `hal_display.cpp` (ali kjer so že ostali EventBus subscriber-ji), dodaj:

```cpp
// Subscribe na vehicle_recog evente — LCD se osveži
// POZOR: EventBus handler tece v eventBusTask — samo nastavi flag,
// dejanski LVGL klic je v LVGL timer kontekstu (ui_refresh_cb je varno).
// Ker ui_refresh_cb ze polni ParkingDisplayData periodicno (1s interval),
// ni potreben ekspliciten flag — samo pospesimo refresh na 0ms za en cikel.

EventBus::subscribe(EventType::VEHICLE_RECOGNIZED, [](const Event&) {
    // ui_refresh_cb bo pri naslednjem tiku prebral novo stanje
    // Ni potrebe za ekspliciten flag ker polling timer ze tece.
    // Opcijsko: lv_timer_set_period(s_ui_timer, 0) za takojsnje posodobitev
});
EventBus::subscribe(EventType::VEHICLE_NEW_MODEL, [](const Event&) { /* enako */ });
EventBus::subscribe(EventType::VEHICLE_DEPARTED,  [](const Event&) { /* enako */ });
EventBus::subscribe(EventType::PARKING_PLACE_CALIBRATED, [](const Event&) { /* enako */ });
```

---

## Povzetek sprememb

| # | Datoteka | Sprememba |
|---|---|---|
| 1 | `screen_main.h` | `ParkingDisplayData` + 3 nova polja |
| 2 | `screen_main.cpp` | `#include "vehicle_recog.h"` |
| 3 | `screen_main.cpp` | `pkg_open_rename_dialog()` — LVGL KB dialog |
| 4 | `screen_main.cpp` | `pkg_open_calibrate_dialog()` — DA/NE dialog |
| 5 | `screen_main.cpp` | `pkg_event_cb()` — 2s + 10s long press |
| 6 | `screen_main.cpp` | `pkg_apply()` — vr_state → vizualno stanje |
| 7 | `hal_display.cpp` | `#include "vehicle_recog.h"` + polnjenje ParkingDisplayData |
| 8 | `hal_display.cpp` | EventBus subscribe na 4 vehicle_recog evente |

**Datoteke ki se NE spreminjajo:**
- `hal_tof.cpp/.h`, `sensor_mgr.cpp`, `vehicle_recog.cpp` — nič
