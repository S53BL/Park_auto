# NAVODILO ZA AGENTA — Zamenjava compress_assets.py
# Projekt: Park_auto | Datum: 2026-05-14

## KAJ SE ZAMENJA IN ZAKAJ

Skripta `scripts/compress_assets.py` je dobila cleanup logiko (v1.1).

**Sprememba:** Pred generacijo `.gz` datotek skripta zdaj pregleda `data/assets/`
in zbriše vse datoteke ki nimajo para v `src/assets/`. To prepreči soobstoj
zastarelih ostankov (npr. stari `data/assets/index.html` placeholder iz faze 1
ki je povzročil, da web UI ni deloval).

Logika je konzervativna — briše samo datoteke brez para, skrite datoteke
(`.gitkeep` itd.) pušča pri miru.

## NALOGA AGENTA

Zamenjaj `scripts/compress_assets.py` s priloženo datoteko:

```bash
cp [pot_do_priložene]/compress_assets.py scripts/compress_assets.py
```

Preveri vsebino:
```bash
grep -n "CLEANUP" scripts/compress_assets.py
# Mora najti vrstico z "CLEANUP: odstranil zastarelo datoteko"
```

Nato git commit:
```bash
git add scripts/compress_assets.py
git commit -m "fix: compress_assets.py v1.1 — cleanup zastarelih datotek iz data/assets/"
```

## ČESAR AGENT NE DELA
- ❌ Ne poganja skripte ročno
- ❌ Ne dela uploadfs ali upload
- ❌ Ne posodablja data/assets/ direktno

Skripta se bo samodejno pognala ob naslednjem `pio run --target uploadfs`.
