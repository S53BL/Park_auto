# NAVODILO ZA AGENTA — Integracija web_ui sync + SD midnight flush
# Projekt: Park_auto (ESP32-S3 parkirišče)
# Datum: 2026-05
# Avtor sprememb: Claude Sonnet + S53BL

## KAJ TA SET NAREDI (2 neodvisni spremembi)

### Sprememba A — ESPAsyncWebServer → sinhroni WebServer
Zamenjava HTTP strežnika. Cilj: sprostiti ~10 KB SRAM
(AsyncTCP task stack 6144 B + LwIP socket internali ~4372 B).
Sinhroni WebServer je funkcionalno identičen za enega občasnega uporabnika.

### Sprememba B — SD = backup medij, logi samo v PSRAM
SD_MMC.open() se med normalnim delovanjem ne kliče več.
Nov task flusira loge enkrat na dan ob 00:01.
Cilj: eliminacija SD DMA spike-ov ki so blokirali TCP konekcije.

---

## DATOTEKE ZA KOPIRANJE

Priložene datoteke kopiraj v src/:
- `web_ui.cpp`          → zamenja obstoječ src/web_ui.cpp
- `sd_midnight_flush.cpp` → NOVA datoteka, dodaj v src/
- `sd_midnight_flush.h`   → NOVA datoteka, dodaj v src/

---

## SPREMEMBA 1 — platformio.ini

### Odstrani iz lib_deps:
```
ESP Async WebServer
AsyncTCP
```
ali kakršnokoli varianto ESPAsyncWebServer/AsyncTCP (ime se lahko razlikuje).

### Dodaj v lib_deps (če še ni):
```
WebServer
```
OPOMBA: WebServer je del arduino-esp32 core — v večini primerov ga ni
treba eksplicitno dodati v lib_deps. Preveri ali je že na voljo.

### Odstrani build_flags ki se nanašajo na AsyncTCP (če obstajajo):
```
-D CONFIG_ASYNC_TCP_STACK_SIZE=6144
```
ali podobne.

---

## SPREMEMBA 2 — web_ui.h

Preveri ali web_ui.h vsebuje:
```cpp
#include <ESPAsyncWebServer.h>
AsyncWebServer* web_ui_get_server();
```

Zamenjave:
- Odstrani `#include <ESPAsyncWebServer.h>` (ali `#include <ESPAsyncTCP.h>`)
- Zamenjaj `AsyncWebServer* web_ui_get_server();` z `void* web_ui_get_server();`
- Dodaj deklaracijo: `void web_ui_tick();`

Preveri da web_ui.h vsebuje vse javne funkcije ki jih web_ui.cpp definira:
```cpp
bool web_ui_init();
bool web_ui_begin();
void web_ui_tick();    // NOVA — mora biti deklarirana
void web_ui_stop();
bool web_ui_running();
void* web_ui_get_server();   // vrne nullptr — stub za kompatibilnost
WebUiStats web_ui_get_stats();
```

---

## SPREMEMBA 3 — wifi_manager.cpp (wifiTask zanka)

Najdi glavno zanko wifiTask — tipično:
```cpp
while (true) {
    // ... wifi reconnect logika ...
    vTaskDelay(pdMS_TO_TICKS(XXX));
}
```

### 3a — Dodaj web_ui_tick() v zanko:
```cpp
#include "web_ui.h"   // dodaj če manjka

while (true) {
    // ... obstoječa wifi logika ...
    web_ui_tick();                      // DODAJ — sinhroni HTTP handling
    vTaskDelay(pdMS_TO_TICKS(20));      // interval: 20ms je dovolj
}
```
OPOMBA: Če vTaskDelay že obstaja z drugačnim intervalom, ga nastavi na 20ms
ali manj. web_ui_tick() je hiter (0ms če ni requestov).

### 3b — Ob NTP sinhronizaciji pokliči sd_midnight_flush_notify_ntp():
Najdi mesto kjer wifi_manager logira uspešno NTP sinhronizacijo
(tipično po `configTime()` ali `sntp_*` klic).

```cpp
#include "sd_midnight_flush.h"   // dodaj na vrh datoteke

// ... obstoječa NTP koda ...
logger_set_ntp_synced(true);
sd_midnight_flush_notify_ntp();  // DODAJ takoj za logger_set_ntp_synced
```

---

## SPREMEMBA 4 — bsp.cpp

### 4a — Dodaj include:
```cpp
#include "sd_midnight_flush.h"
```

### 4b — V bsp_tasks_create() ali na koncu bsp_init(), PO task kreaciji:
```cpp
sd_midnight_flush_start();
```

OPOMBA: Klic mora biti PO bsp_tasks_create() in PO sd_mgr_init().
Priporočeno mesto: na koncu bsp_init(), tik pred zadnjim LOGI.

---

## SPREMEMBA 5 — logger.cpp (odstrani periodični SD flush)

### 5a — Odstrani sd_buf_write() klic iz logger_log():
V funkciji `logger_log()` najdi klic:
```cpp
sd_buf_write(line, (size_t)len, force_flush);
```
in ga ODSTRANI (ali zakomentiraj z jasno opombo).

Ohrani vse ostalo: RAM buffer vpis, Serial vpis, mutex.

### 5b — Dodaj komentar:
```cpp
// SD pisanje med normalnim delovanjem ODSTRANJENO (2026-05, Ideja 1).
// Logi gredo SAMO v PSRAM RAM buffer (s_ram_buf) in Serial.
// SD flush enkrat na dan ob 00:01 prek sd_midnight_flush_task.
// logger_flush() ostane za eksplicitne klice (restart, OTA, /api/logs/flush).
```

### 5c — Preveriti: logger_flush() in logger_sd_attach() ostaneta nespremenjeni.
Samo sd_buf_write() klic iz logger_log() se odstrani.

---

## SPREMEMBA 6 — light_logic.cpp

Najdi in ODSTRANI periodični `logger_flush()` klic iz `light_logic_tick()`:
```cpp
// ODSTRANI ta blok:
if ((now_ms - s_last_flush_ms) >= 60000UL) {
    s_last_flush_ms = now_ms;
    logger_flush();
}
```
(ali podobno — iskanje: `logger_flush` v light_logic.cpp)

RAZLOG: logger_flush() med normalnim delovanjem ni več potreben.
SD flush je preseljen na midnight task. Eksplicitni klici ostanejo
(restart, OTA) — tisti so v web_ui.cpp in so že pravilni.

---

## SPREMEMBA 7 — config.h (opcijsko — povečaj LOG_RAM_BUF_SIZE)

Ker SD ni več primary in logi živijo dlje v PSRAM bufferju,
povečaj buffer da pokrije cel dan logov:

```cpp
// STARO:
#define LOG_RAM_BUF_SIZE   (16 * 1024)   // ali kakšna vrednost je zdaj

// NOVO:
#define LOG_RAM_BUF_SIZE   (128 * 1024)  // 128 KB PSRAM — pokrije cel dan logov
```

PSRAM ima ~6.5 MB proste kapacitete — 128 KB je zanemarljivo.
Če LOG_RAM_BUF_SIZE ni v config.h, ga poišči v logger.h ali logger.cpp.

---

## PREVERJANJE PO INTEGRACIJI

### Preveri da se koda prevede brez napak:
1. `pio run` — ne sme biti napak glede ESPAsync*, AsyncTCP
2. Opozorila glede `web_ui_get_server()` vračajoč `void*` so OK — to je stub

### Preveri boot log:
Po flashu v Serial Monitoru preveri:
```
[WEBUI][I] web_ui_begin() — zaganjam sync WebServer na port 80
[WEBUI][I] Web server zagnan: http://X.X.X.X:80/
[SDFLUSH][I] sd_midnight_flush_task OK (stack:3072 SRAM Core1 prio:1)
[SDFLUSH][I] sd_midnight_flush_task start — čakam NTP sinhronizacijo
```

Po NTP sinhronizaciji:
```
[SDFLUSH][I] NTP sync sporočen — midnight flush bo aktiven ob 00:01
[SDFLUSH][I] NTP OK — midnight flush aktiven (vsak dan ob 00:01)
```

### Preveri SRAM:
Po web_ui_begin() mora biti prosti SRAM večji kot prej:
- PREJ: ~14028 B
- PRIČAKOVANO: ~20000–24000 B (prihranek ~10KB iz AsyncTCP odstranitve)
  minus ~3600 B za SdFlush task = neto ~+6–10 KB

### Test web vmesnika:
Odpri brskalnik → http://[IP]/ — stran se mora naložiti.
Testiraj: /api/status/system, /api/logs, POST /api/ssr.

---

## KAJ AGENT NE NAREDI

- NE prevaja kode (`pio run` je ročno delo)
- NE commitira na GIT (ročno delo)
- NE nalagala na Box

## ZNANE OMEJITVE SYNC WEBSERVER

- File download (/files?path=X) blokira wifiTask med prenosom
  → za log datoteke <50KB je to <500ms, sprejemljivo
- OTA upload je počasnejši kot async (~2-3x) — za citizen developer OK
- Samo en HTTP request naenkrat — za enega uporabnika ni razlike
