# AGENT NAVODILO — hal_radar v2.0 Polling Arhitektura
# Projekt: Avtomatizacija Pokritega Parkirišča
# Datum: 2026-05
# Repozitorij: https://github.com/S53BL/Park_auto

## NAMEN SPREMEMBE

Zamenjava IRQ-pin polling z drain zanko (v1.x) s čistim periodičnim pollingom (v2.0).
Razlog: max_loops napake, OE! overflowi, Wire1 mutex blokada do 96ms.
Podrobna obrazložitev je v komentarjih hal_radar.cpp (glava datoteke).

## DATOTEKE ZA ZAMENJAVO (drop-in)

Naslednje datoteke **v celoti zamenjaj** z verzijami iz tega deliverytja:

1. `src/hal_radar.cpp` → zamenjaj z `hal_radar.cpp`
2. `src/hal_radar.h`   → zamenjaj z `hal_radar.h`

## DATOTEKE ZA ROČNO DOPOLNITEV

### A) `src/config.h`

Poišči sekcijo z RADAR_ konstantami (obstaja RADAR_TASK_STACK, RADAR_OE_LOG_INTERVAL_MS ipd.)
in **dodaj za njimi**:

```cpp
// Radar polling interval (v2.0 arhitektura)
#define RADAR_POLL_INTERVAL_MS_DEFAULT   50u
#define RADAR_POLL_INTERVAL_MIN_MS       10u
#define RADAR_POLL_INTERVAL_MAX_MS      100u
#define RADAR_MAX_CONSECUTIVE_OVERFLOWS  10u
```

Opcijsko: obstoječo konstanto `RADAR_DRAIN_MAX_LOOPS` lahko pustiš ali odstraniš —
v v2.0 ni več v uporabi (ni napake če ostane).

### B) `src/config_mgr.h` → struct Config

Poišči `uint8_t radar_persistence_n;` in **za njim** dodaj:

```cpp
// Radar polling interval in overflow prag (hal_radar v2.0)
uint32_t radar_poll_interval_ms;      // default: 50, min: 10, max: 100
uint32_t radar_max_consec_overflows;  // default: 10, min: 1,  max: 100
```

V `inline Config config_defaults()` poišči `c.radar_persistence_n = 3;`
in **za njim** dodaj:

```cpp
c.radar_poll_interval_ms     = RADAR_POLL_INTERVAL_MS_DEFAULT;  // 50
c.radar_max_consec_overflows = RADAR_MAX_CONSECUTIVE_OVERFLOWS;  // 10
```

### C) `src/config_mgr.cpp`

**C1 — NVS ključi** (poišči `#define NVS_K_RADAR_PERSIST` in dodaj za njim):

```cpp
#define NVS_K_RADAR_POLL_IV   "r_poll_iv"    // radar_poll_interval_ms
#define NVS_K_RADAR_MAX_OVF   "r_max_ovf"    // radar_max_consec_overflows
```

**C2 — Mejne vrednosti** (poišči obstoječe CFG_MIN/MAX za radar in dodaj):

```cpp
#define CFG_MIN_RADAR_POLL_IV    10u
#define CFG_MAX_RADAR_POLL_IV   100u
#define CFG_MIN_RADAR_MAX_OVF    1u
#define CFG_MAX_RADAR_MAX_OVF  100u
```

**C3 — load_and_validate()** (poišči blok ki piše `radar_persistence_n` in dodaj ZA njim):

```cpp
VALIDATE_U32(prefs, NVS_K_RADAR_POLL_IV,
             radar_poll_interval_ms,
             CFG_MIN_RADAR_POLL_IV, CFG_MAX_RADAR_POLL_IV,
             def.radar_poll_interval_ms);

VALIDATE_U32(prefs, NVS_K_RADAR_MAX_OVF,
             radar_max_consec_overflows,
             CFG_MIN_RADAR_MAX_OVF, CFG_MAX_RADAR_MAX_OVF,
             def.radar_max_consec_overflows);
```

**C4 — write_all_to_nvs()** (poišči `prefs.putUChar(NVS_K_RADAR_PERSIST, ...)` in dodaj ZA njim):

```cpp
prefs.putUInt(NVS_K_RADAR_POLL_IV, s_config.radar_poll_interval_ms);
prefs.putUInt(NVS_K_RADAR_MAX_OVF, s_config.radar_max_consec_overflows);
```

## PREVERJANJE PO INTEGRACIJI

1. Komaj se prevede brez napak:
   - `config.h` mora imeti vse RADAR_POLL_INTERVAL_* in RADAR_MAX_CONSECUTIVE_OVERFLOWS
   - `Config` struct mora imeti `radar_poll_interval_ms` in `radar_max_consec_overflows`
   - hal_radar.cpp include-a te konstante prek `config.h` in `config_mgr.h`

2. Preveri da ni ostankov v1.x ki bi povzročali konflikt:
   - `process_chip_irq()` — NE SME biti v hal_radar.cpp (odstranjeno v v2.0)
   - `process_one_channel()` — NE SME biti v hal_radar.cpp
   - `rr_loops` / `keep_polling` spremenljivke — NE SMEJO biti v hal_radar.cpp
   - `attachInterrupt` klici za IO41/IO42 — NE SMEJO biti (IRQ pini ohranimo
     samo kot INPUT_PULLUP za diagnostično digitalRead v log-u)

3. Simboli ki MORAJO obstajati (klicani iz hal_radar.cpp):
   - `bsp_get_wire1_mutex()` — iz bsp.h/bsp.cpp (ni sprememb)
   - `config_get()` — iz config_mgr.h (ni sprememb)
   - `RADAR_TASK_STACK` — iz config.h (obstoječ)
   - `RADAR_OE_LOG_INTERVAL_MS` — iz config.h (obstoječ)
   - `RADAR_PUBLISH_INTERVAL_MS` — iz config.h (obstoječ)
   - `RADAR_POLL_INTERVAL_MS_DEFAULT` — novo v config.h
   - `RADAR_POLL_INTERVAL_MIN_MS` / `RADAR_POLL_INTERVAL_MAX_MS` — novo
   - `RADAR_MAX_CONSECUTIVE_OVERFLOWS` — novo

## ČESAR AGENT NE DELA

- NE prevaja kode
- NE nalaga na GIT
- NE spreminja web UI JavaScript (to je ločen task)
- NE spreminja sensor_mgr.cpp, event_bus.cpp, light_logic.cpp —
  hal_radar javni API je nespremenjen (drop-in zamenjava)

## OPOMBA O ODSTRANJENEM KODI

Iz hal_radar.cpp so v celoti odstranjene naslednje funkcije:
- `process_one_channel()` — zamenjana z `poll_one_channel()`
- `process_chip_irq()` — ni več potrebna
- `isr_chip1()` / `isr_chip2()` — ISR funkciji (dead code v v1.x, odstranjeni)

hal_radar.h javni API je **100% enak** v1.x — nobena zunanja koda se ne
mora spremeniti.
